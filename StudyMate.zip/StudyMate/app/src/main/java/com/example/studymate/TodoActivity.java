package com.example.studymate;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TodoActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "studymate_prefs";
    private static final String KEY_TODOS = "key_todos";

    private EditText etTaskInput;
    private Button btnAddTask;
    private ListView lvTasks;

    private List<TodoItem> todoList;
    private TodoAdapter adapter;
    private SharedPreferences sharedPreferences;

    public static class TodoItem {
        String title;
        boolean isDone;

        public TodoItem(String title, boolean isDone) {
            this.title = title;
            this.isDone = isDone;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_todo);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        etTaskInput = findViewById(R.id.etTaskInput);
        btnAddTask = findViewById(R.id.btnAddTask);
        lvTasks = findViewById(R.id.lvTasks);

        todoList = loadTodos();
        adapter = new TodoAdapter(this, todoList);
        lvTasks.setAdapter(adapter);

        btnAddTask.setOnClickListener(v -> {
            String title = etTaskInput.getText().toString().trim();
            if (TextUtils.isEmpty(title)) {
                Toast.makeText(TodoActivity.this, "Please enter a task title", Toast.LENGTH_SHORT).show();
                return;
            }
            todoList.add(new TodoItem(title, false));
            adapter.notifyDataSetChanged();
            saveTodos();
            etTaskInput.setText("");
        });
    }

    private void saveTodos() {
        JSONArray jsonArray = new JSONArray();
        for (TodoItem item : todoList) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("title", item.title);
                jsonObject.put("isDone", item.isDone);
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        sharedPreferences.edit().putString(KEY_TODOS, jsonArray.toString()).apply();
    }

    private List<TodoItem> loadTodos() {
        List<TodoItem> list = new ArrayList<>();
        String jsonString = sharedPreferences.getString(KEY_TODOS, null);
        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String title = jsonObject.getString("title");
                    boolean isDone = jsonObject.getBoolean("isDone");
                    list.add(new TodoItem(title, isDone));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    private class TodoAdapter extends ArrayAdapter<TodoItem> {

        public TodoAdapter(Context context, List<TodoItem> items) {
            super(context, 0, items);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_todo, parent, false);
            }

            TodoItem item = getItem(position);
            CheckBox cbTask = convertView.findViewById(R.id.cbTask);
            Button btnDelete = convertView.findViewById(R.id.btnDelete);

            if (item != null) {
                cbTask.setOnCheckedChangeListener(null);
                cbTask.setText(item.title);
                cbTask.setChecked(item.isDone);

                cbTask.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    item.isDone = isChecked;
                    saveTodos();
                });

                btnDelete.setOnClickListener(v -> {
                    todoList.remove(position);
                    notifyDataSetChanged();
                    saveTodos();
                });
            }

            return convertView;
        }
    }
}
