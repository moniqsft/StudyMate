package com.example.studymate;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RoutineActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "studymate_prefs";
    private static final String KEY_ROUTINES = "key_routines";

    private EditText etSubject;
    private EditText etDayTime;
    private EditText etRoom;
    private Button btnAddRoutine;
    private ListView lvRoutine;

    private List<RoutineItem> routineList;
    private RoutineAdapter adapter;
    private SharedPreferences sharedPreferences;

    public static class RoutineItem {
        String subject;
        String dayTime;
        String room;

        public RoutineItem(String subject, String dayTime, String room) {
            this.subject = subject;
            this.dayTime = dayTime;
            this.room = room;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_routine);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        etSubject = findViewById(R.id.etSubject);
        etDayTime = findViewById(R.id.etDayTime);
        etRoom = findViewById(R.id.etRoom);
        btnAddRoutine = findViewById(R.id.btnAddRoutine);
        lvRoutine = findViewById(R.id.lvRoutine);

        routineList = loadRoutines();
        adapter = new RoutineAdapter(this, routineList);
        lvRoutine.setAdapter(adapter);

        btnAddRoutine.setOnClickListener(v -> {
            String subject = etSubject.getText().toString().trim();
            String dayTime = etDayTime.getText().toString().trim();
            String room = etRoom.getText().toString().trim();

            if (TextUtils.isEmpty(subject)) {
                Toast.makeText(RoutineActivity.this, "Please enter subject name", Toast.LENGTH_SHORT).show();
                return;
            }

            routineList.add(new RoutineItem(subject, dayTime, room));
            adapter.notifyDataSetChanged();
            saveRoutines();

            etSubject.setText("");
            etDayTime.setText("");
            etRoom.setText("");
        });
    }

    private void saveRoutines() {
        JSONArray jsonArray = new JSONArray();
        for (RoutineItem item : routineList) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("subject", item.subject);
                jsonObject.put("dayTime", item.dayTime);
                jsonObject.put("room", item.room);
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        sharedPreferences.edit().putString(KEY_ROUTINES, jsonArray.toString()).apply();
    }

    private List<RoutineItem> loadRoutines() {
        List<RoutineItem> list = new ArrayList<>();
        String jsonString = sharedPreferences.getString(KEY_ROUTINES, null);
        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String subject = jsonObject.getString("subject");
                    String dayTime = jsonObject.optString("dayTime", "");
                    String room = jsonObject.optString("room", "");
                    list.add(new RoutineItem(subject, dayTime, room));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    private class RoutineAdapter extends ArrayAdapter<RoutineItem> {

        public RoutineAdapter(Context context, List<RoutineItem> items) {
            super(context, 0, items);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_routine, parent, false);
            }

            RoutineItem item = getItem(position);
            TextView tvSubject = convertView.findViewById(R.id.tvSubject);
            TextView tvDayTime = convertView.findViewById(R.id.tvDayTime);
            TextView tvRoom = convertView.findViewById(R.id.tvRoom);
            Button btnDelete = convertView.findViewById(R.id.btnDeleteRoutine);

            if (item != null) {
                tvSubject.setText(item.subject);
                tvDayTime.setText(TextUtils.isEmpty(item.dayTime) ? "No time specified" : item.dayTime);
                tvRoom.setText(TextUtils.isEmpty(item.room) ? "No room specified" : "Room: " + item.room);

                btnDelete.setOnClickListener(v -> {
                    routineList.remove(position);
                    notifyDataSetChanged();
                    saveRoutines();
                });
            }

            return convertView;
        }
    }
}
